/**
 * query.js
 * ────────
 * Knowledge-graph query engine.
 * Finds ingredient substitutions by discovering shared connections,
 * ranks them by strength, and generates explanation sentences.
 *
 * Depends on: NODES, EDGES, adjacency, nodeMap (from graph-data.js / graph.js)
 */

// ─── Core algorithm ───────────────────────────────────────────────────────

/**
 * Find substitution candidates for a given ingredient.
 *
 * Strategy (mirrors the drug-disease shared-target approach):
 *   For each neighbor N of the source ingredient A:
 *     For each neighbor C of N (where C is an ingredient and C ≠ A):
 *       score(A→C via N) = average(weight(A,N), weight(N,C))
 *   Final score for C = max score across all shared paths.
 *
 * @param {string} sourceId       - Ingredient to substitute
 * @param {string|null} contextId - Optional: filter by cuisine id
 * @returns {Array<{id, score, sharedNodes}>} sorted best→worst
 */
function findSubstitutions(sourceId, contextId) {
  const sourceNeighbors = adjacency[sourceId]; // { nodeId: weight }

  const candidates = {}; // { candidateId: { score, sharedNodes[] } }

  for (const [sharedId, weightAS] of Object.entries(sourceNeighbors)) {
    const sharedNeighbors = adjacency[sharedId];

    for (const [candidateId, weightSC] of Object.entries(sharedNeighbors)) {
      // Must be a different ingredient
      if (candidateId === sourceId) continue;
      if (nodeMap[candidateId].type !== 'ingredient') continue;

      // If a cuisine context is specified, at least one shared node must be
      // that cuisine, or the candidate must connect to it directly.
      if (contextId) {
        const sharedNode = nodeMap[sharedId];
        const candidateConnectsToContext = adjacency[candidateId][contextId] !== undefined;
        const pathIsContext = sharedId === contextId;
        if (!pathIsContext && !candidateConnectsToContext) continue;
      }

      const pathScore = (weightAS + weightSC) / 2;

      if (!candidates[candidateId]) {
        candidates[candidateId] = { score: 0, sharedNodes: [] };
      }

      // Keep the best score across all paths
      if (pathScore > candidates[candidateId].score) {
        candidates[candidateId].score = pathScore;
      }

      candidates[candidateId].sharedNodes.push({
        node:    nodeMap[sharedId],
        weightA: weightAS,
        weightC: weightSC,
        pathScore,
      });
    }
  }

  // Sort by score descending, return top results
  return Object.entries(candidates)
    .map(([id, data]) => ({
      id,
      score:       data.score,
      sharedNodes: data.sharedNodes.sort((a, b) => b.pathScore - a.pathScore),
    }))
    .sort((a, b) => b.score - a.score);
}

// ─── Explanation generator ────────────────────────────────────────────────

/**
 * Generate a human-readable explanation for why candidate C substitutes source A.
 *
 * @param {object} sourceNode
 * @param {object} candidateNode
 * @param {object[]} sharedNodes
 * @returns {string}
 */
function buildExplanation(sourceNode, candidateNode, sharedNodes) {
  const uniqueShared = [...new Map(sharedNodes.map(s => [s.node.id, s])).values()];
  const top = uniqueShared[0];

  const flavorShared = uniqueShared
    .filter(s => s.node.type === 'flavor')
    .map(s => s.node.label.toLowerCase());

  const cuisineShared = uniqueShared
    .filter(s => s.node.type === 'cuisine')
    .map(s => s.node.label);

  const sharedNames = uniqueShared.map(s => s.node.label).join(', ');
  const topPct      = Math.round(top.pathScore * 100);

  let explanation = `${candidateNode.label} shares <strong>${sharedNames}</strong> with ${sourceNode.label}. `;
  explanation += `The strongest shared path is through "${top.node.label}" (${topPct}% compatibility). `;

  if (flavorShared.length > 0) {
    explanation += `Both ingredients contribute similar <em>${flavorShared.join(' and ')}</em> qualities to a dish`;
    if (cuisineShared.length > 0) {
      explanation += `, and both appear in ${cuisineShared.join(' and ')} cooking`;
    }
    explanation += '.';
  } else if (cuisineShared.length > 0) {
    explanation += `Both are commonly used in ${cuisineShared.join(' and ')} cuisine.`;
  }

  return explanation;
}

// ─── Score badge ──────────────────────────────────────────────────────────

/**
 * Returns a label and CSS class for a given 0–1 score.
 * @param {number} score
 * @returns {{ label: string, cssClass: string }}
 */
function scoreLabel(score) {
  if (score >= 0.70) return { label: 'High match',   cssClass: 'high' };
  if (score >= 0.40) return { label: 'Good match',   cssClass: 'mid'  };
  return               { label: 'Possible',           cssClass: 'low'  };
}

// ─── Render results ───────────────────────────────────────────────────────

/**
 * Run a substitution query and render results into #results-output.
 * Also updates graph highlighting.
 */
function runQuery() {
  const sourceId  = document.getElementById('sel-ingredient').value;
  const contextId = document.getElementById('sel-context').value || null;

  if (!sourceId) return;

  const sourceNode = nodeMap[sourceId];
  const results    = findSubstitutions(sourceId, contextId).slice(0, 4);
  const output     = document.getElementById('results-output');

  if (results.length === 0) {
    output.innerHTML = `<p class="placeholder">No substitutions found for ${sourceNode.label} in that context.</p>`;
    resetGraphHighlight();
    return;
  }

  // Build highlight sets
  const highlightNodeIds  = [sourceId];
  const highlightEdgePairs = [];

  let html = `<p class="results-title">Top substitutions for <strong>${sourceNode.label}</strong>` +
             (contextId ? ` in <strong>${nodeMap[contextId].label}</strong> cuisine` : '') + ':</p>';

  html += '<div class="results-list">';

  for (const result of results) {
    const candidateNode = nodeMap[result.id];
    const { label, cssClass } = scoreLabel(result.score);
    const pct         = Math.round(result.score * 100);
    const explanation = buildExplanation(sourceNode, candidateNode, result.sharedNodes);

    // Accumulate nodes/edges for highlight
    highlightNodeIds.push(result.id);
    for (const s of result.sharedNodes) {
      highlightNodeIds.push(s.node.id);
      highlightEdgePairs.push([sourceId, s.node.id]);
      highlightEdgePairs.push([result.id, s.node.id]);
    }

    html += `
      <div class="result-item">
        <div class="result-header">
          <span class="result-name">${candidateNode.label}</span>
          <span class="badge ${cssClass}">${label} &mdash; ${pct}%</span>
        </div>
        <p class="result-reason">${explanation}</p>
      </div>`;
  }

  html += '</div>';
  output.innerHTML = html;

  // Update graph
  highlightGraph([...new Set(highlightNodeIds)], highlightEdgePairs);
}
