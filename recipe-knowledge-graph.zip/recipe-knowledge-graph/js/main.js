/**
 * main.js
 * ───────
 * Entry point. Initializes the graph and populates the UI controls.
 * Depends on: graph.js, query.js, graph-data.js
 */

/** Populate the ingredient and cuisine dropdowns from NODES data */
function populateControls() {
  const selIngredient = document.getElementById('sel-ingredient');
  const selContext    = document.getElementById('sel-context');

  const ingredients = NODES.filter(n => n.type === 'ingredient');
  const cuisines    = NODES.filter(n => n.type === 'cuisine');

  for (const n of ingredients) {
    selIngredient.add(new Option(n.label, n.id));
  }

  for (const n of cuisines) {
    selContext.add(new Option(n.label, n.id));
  }
}

/** Reset the view: clear highlights, clear results */
function resetView() {
  resetGraphHighlight();
  document.getElementById('results-output').innerHTML =
    '<p class="placeholder">Select an ingredient above and click "Find Matches".</p>';
}

/** Initialize on page load */
function init() {
  drawGraph();
  populateControls();
}

window.addEventListener('DOMContentLoaded', init);
