/**
 * graph.js
 * ────────
 * Renders the SVG knowledge graph and handles node click highlighting.
 * Depends on: NODES, EDGES (from graph-data.js)
 */

const SVG_NS = 'http://www.w3.org/2000/svg';

// Visual config
const NODE_RADIUS = 22;
const VIEWBOX_W   = 680;
const VIEWBOX_H   = 360;

const NODE_COLORS = {
  ingredient: { fill: '#1D9E75', stroke: '#0F6E56', text: '#ffffff' },
  cuisine:    { fill: '#7F77DD', stroke: '#534AB7', text: '#ffffff' },
  flavor:     { fill: '#D85A30', stroke: '#993C1D', text: '#ffffff' },
};

/** Build a lookup map: nodeId → node object */
function buildNodeMap() {
  return Object.fromEntries(NODES.map(n => [n.id, n]));
}

/** Build a neighbor map: nodeId → { neighborId: weight } */
function buildAdjacency() {
  const adj = {};
  for (const n of NODES) adj[n.id] = {};
  for (const e of EDGES) {
    adj[e.a][e.b] = e.weight;
    adj[e.b][e.a] = e.weight;
  }
  return adj;
}

const nodeMap  = buildNodeMap();
const adjacency = buildAdjacency();

// ─── SVG element helpers ───────────────────────────────────────────────────

function svgEl(tag, attrs) {
  const el = document.createElementNS(SVG_NS, tag);
  for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
  return el;
}

function svgText(content, attrs) {
  const el = svgEl('text', attrs);
  el.textContent = content;
  return el;
}

// ─── Draw ─────────────────────────────────────────────────────────────────

let edgeElements = []; // { el, a, b, weight }
let nodeElements = {}; // nodeId → { group, circle }

function drawGraph() {
  const svg = document.getElementById('kg-svg');
  svg.setAttribute('viewBox', `0 0 ${VIEWBOX_W} ${VIEWBOX_H}`);
  svg.setAttribute('width', '100%');
  svg.innerHTML = '';

  // Arrow marker definition
  const defs = svgEl('defs', {});
  const marker = svgEl('marker', {
    id: 'arrowhead',
    viewBox: '0 0 10 10',
    refX: '8', refY: '5',
    markerWidth: '5', markerHeight: '5',
    orient: 'auto-start-reverse',
  });
  const markerPath = svgEl('path', {
    d: 'M2 1L8 5L2 9',
    fill: 'none',
    stroke: '#aaa',
    'stroke-width': '1.5',
    'stroke-linecap': 'round',
    'stroke-linejoin': 'round',
  });
  marker.appendChild(markerPath);
  defs.appendChild(marker);
  svg.appendChild(defs);

  // Draw edges first (so nodes appear on top)
  edgeElements = [];
  for (const e of EDGES) {
    const a = nodeMap[e.a];
    const b = nodeMap[e.b];
    const line = svgEl('line', {
      x1: a.x, y1: a.y,
      x2: b.x, y2: b.y,
      stroke: '#ccc',
      'stroke-width': 0.5 + e.weight * 1.5,
      opacity: 0.35 + e.weight * 0.3,
      class: 'edge',
      'data-a': e.a,
      'data-b': e.b,
    });
    svg.appendChild(line);
    edgeElements.push({ el: line, a: e.a, b: e.b, weight: e.weight });
  }

  // Draw nodes
  nodeElements = {};
  for (const n of NODES) {
    const c = NODE_COLORS[n.type];
    const g = svgEl('g', {
      class: `node node-${n.type}`,
      'data-id': n.id,
      style: 'cursor: pointer;',
      role: 'button',
      tabindex: '0',
      'aria-label': `${n.label} (${n.type})`,
    });

    const circle = svgEl('circle', {
      cx: n.x, cy: n.y, r: NODE_RADIUS,
      fill: c.fill,
      stroke: c.stroke,
      'stroke-width': '1.5',
      class: 'node-circle',
    });

    // Split long labels onto two lines
    const words = n.label.split(' ');
    if (words.length === 1) {
      const t = svgText(n.label, {
        x: n.x, y: n.y,
        'text-anchor': 'middle',
        'dominant-baseline': 'central',
        fill: c.text,
        'font-size': '10',
        'font-weight': '600',
        'pointer-events': 'none',
      });
      g.appendChild(circle);
      g.appendChild(t);
    } else {
      const t1 = svgText(words[0], {
        x: n.x, y: n.y - 6,
        'text-anchor': 'middle',
        'dominant-baseline': 'central',
        fill: c.text,
        'font-size': '9',
        'font-weight': '600',
        'pointer-events': 'none',
      });
      const t2 = svgText(words.slice(1).join(' '), {
        x: n.x, y: n.y + 6,
        'text-anchor': 'middle',
        'dominant-baseline': 'central',
        fill: c.text,
        'font-size': '9',
        'font-weight': '600',
        'pointer-events': 'none',
      });
      g.appendChild(circle);
      g.appendChild(t1);
      g.appendChild(t2);
    }

    g.addEventListener('click', () => onNodeClick(n.id));
    g.addEventListener('keydown', e => { if (e.key === 'Enter') onNodeClick(n.id); });
    svg.appendChild(g);
    nodeElements[n.id] = { group: g, circle };
  }
}

// ─── Highlight ────────────────────────────────────────────────────────────

/**
 * Highlight a set of nodes and the edges connecting them.
 * Everything else is dimmed.
 *
 * @param {string[]} activeNodeIds
 * @param {Array<[string,string]>} activeEdgePairs
 */
function highlightGraph(activeNodeIds, activeEdgePairs) {
  const nodeSet = new Set(activeNodeIds);
  const edgeSet = new Set(activeEdgePairs.map(([a, b]) => `${a}|${b}`));

  for (const [id, { circle }] of Object.entries(nodeElements)) {
    circle.style.opacity = nodeSet.has(id) ? '1' : '0.15';
  }

  for (const { el, a, b } of edgeElements) {
    const key1 = `${a}|${b}`, key2 = `${b}|${a}`;
    const active = edgeSet.has(key1) || edgeSet.has(key2);
    el.style.opacity = active ? '1' : '0.05';
    el.style.stroke  = active ? '#EF9F27' : '#ccc';
  }
}

/** Remove all highlighting */
function resetGraphHighlight() {
  for (const { circle } of Object.values(nodeElements)) {
    circle.style.opacity = '1';
  }
  for (const { el } of edgeElements) {
    el.style.opacity = '';
    el.style.stroke  = '#ccc';
  }
}

// ─── Node click ───────────────────────────────────────────────────────────

function onNodeClick(id) {
  const neighbors = Object.keys(adjacency[id]);
  const pairs = neighbors.map(nb => [id, nb]);
  highlightGraph([id, ...neighbors], pairs);

  // Sync dropdown and run query
  const sel = document.getElementById('sel-ingredient');
  if (sel) sel.value = id;
  runQuery();
}
