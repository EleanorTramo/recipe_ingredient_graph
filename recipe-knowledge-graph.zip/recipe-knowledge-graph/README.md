# Recipe Ingredient Knowledge Graph

A browser-based knowledge graph that maps ingredients, cuisines, and flavor profiles — and uses shared connections to recommend smart ingredient substitutions.

## Features

- **Interactive SVG graph** — 14 nodes (ingredients, cuisines, flavor profiles) and 22 weighted connections
- **Shared-connection discovery** — finds substitutes by looking for ingredients that share the same flavor profiles and cuisines as your chosen ingredient (same approach as biological target-sharing in drug repurposing research)
- **Ranked results** — substitutions are scored by averaging edge weights along shared paths, then sorted best → worst
- **Explanation sentences** — each recommendation explains *why* it was suggested (shared flavors, shared cuisines, strongest path)
- **Graph highlighting** — relevant nodes and edges light up when a query runs
- **Dark mode** — automatic via `prefers-color-scheme`
- **No dependencies** — vanilla HTML, CSS, and JavaScript; no build step required

## Project Structure

```
recipe-knowledge-graph/
├── index.html          # Main page
├── css/
│   └── style.css       # All styles (light + dark mode)
├── js/
│   ├── graph.js        # SVG rendering and node highlighting
│   ├── query.js        # Substitution algorithm and result rendering
│   └── main.js         # Initialisation and control wiring
└── data/
    └── graph-data.js   # All nodes and edges (edit this to extend the graph)
```

## Running It

No server needed. Just open `index.html` in a browser:

```bash
# macOS
open index.html

# Linux
xdg-open index.html

# Or use any local server, e.g.:
npx serve .
python3 -m http.server
```

## How the Algorithm Works

The substitution engine mirrors the *shared biological target* technique used in drug repurposing:

1. For the selected ingredient **A**, find all its neighbors (flavor profiles, cuisines) **N₁, N₂, …**
2. For each neighbor **Nᵢ**, find all *other* ingredients **C** that also connect to **Nᵢ**
3. Score each path: `score(A→C via Nᵢ) = (weight(A, Nᵢ) + weight(Nᵢ, C)) / 2`
4. A candidate's final score = the maximum score across all shared paths
5. Results are ranked and capped at the top 4

### Score labels

| Score  | Label      |
|--------|------------|
| ≥ 70%  | High match |
| ≥ 40%  | Good match |
| < 40%  | Possible   |

## Extending the Graph

All data lives in `data/graph-data.js`. To add a new ingredient:

```js
// In NODES array
{ id: 'lime', label: 'Lime', type: 'ingredient', x: 380, y: 90 },

// In EDGES array
{ a: 'lime', b: 'acidic',   weight: 0.92 },
{ a: 'lime', b: 'mexican',  weight: 0.88 },
```

Node types: `'ingredient'` | `'cuisine'` | `'flavor'`  
Edge weights: `0.0` (weak) → `1.0` (strong)

The graph re-renders automatically on page load.

## Deploying to GitHub Pages

1. Push this folder to a GitHub repository
2. Go to **Settings → Pages**
3. Set source to **Deploy from branch → main → / (root)**
4. Your site will be live at `https://<username>.github.io/<repo-name>/`
