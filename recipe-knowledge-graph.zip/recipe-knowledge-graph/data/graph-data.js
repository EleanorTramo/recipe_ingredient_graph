/**
 * graph-data.js
 * ─────────────
 * All nodes and edges for the recipe knowledge graph.
 *
 * Node types:  'ingredient' | 'cuisine' | 'flavor'
 * Edge weight: 0.0 – 1.0  (strength of relationship)
 *
 * To add a node: push an object into NODES.
 * To add a connection: push an object into EDGES.
 * x / y are the starting SVG coordinates (adjusted automatically on resize).
 */

const NODES = [
  // ── Ingredients ──────────────────────────────────────────────────────────
  { id: 'tomato',   label: 'Tomato',     type: 'ingredient', x: 170, y: 80  },
  { id: 'lemon',    label: 'Lemon',      type: 'ingredient', x: 310, y: 55  },
  { id: 'miso',     label: 'Miso',       type: 'ingredient', x: 490, y: 75  },
  { id: 'garlic',   label: 'Garlic',     type: 'ingredient', x: 100, y: 190 },
  { id: 'tamarind', label: 'Tamarind',   type: 'ingredient', x: 270, y: 180 },
  { id: 'parmesan', label: 'Parmesan',   type: 'ingredient', x: 430, y: 170 },
  { id: 'anchovy',  label: 'Anchovy',    type: 'ingredient', x: 580, y: 190 },
  { id: 'soy',      label: 'Soy Sauce',  type: 'ingredient', x: 510, y: 290 },

  // ── Cuisines ─────────────────────────────────────────────────────────────
  { id: 'italian',  label: 'Italian',    type: 'cuisine',    x: 200, y: 280 },
  { id: 'japanese', label: 'Japanese',   type: 'cuisine',    x: 590, y: 95  },
  { id: 'indian',   label: 'Indian',     type: 'cuisine',    x: 330, y: 300 },

  // ── Flavor Profiles ──────────────────────────────────────────────────────
  { id: 'umami',    label: 'Umami',      type: 'flavor',     x: 420, y: 260 },
  { id: 'acidic',   label: 'Acidic',     type: 'flavor',     x: 220, y: 145 },
  { id: 'savory',   label: 'Savory',     type: 'flavor',     x: 95,  y: 295 },
];

const EDGES = [
  // tomato
  { a: 'tomato',   b: 'acidic',   weight: 0.90 },
  { a: 'tomato',   b: 'umami',    weight: 0.70 },
  { a: 'tomato',   b: 'italian',  weight: 0.85 },

  // lemon
  { a: 'lemon',    b: 'acidic',   weight: 0.95 },
  { a: 'lemon',    b: 'indian',   weight: 0.60 },

  // tamarind
  { a: 'tamarind', b: 'acidic',   weight: 0.85 },
  { a: 'tamarind', b: 'indian',   weight: 0.90 },

  // miso
  { a: 'miso',     b: 'umami',    weight: 0.92 },
  { a: 'miso',     b: 'japanese', weight: 0.95 },
  { a: 'miso',     b: 'savory',   weight: 0.75 },

  // parmesan
  { a: 'parmesan', b: 'umami',    weight: 0.88 },
  { a: 'parmesan', b: 'savory',   weight: 0.80 },
  { a: 'parmesan', b: 'italian',  weight: 0.90 },

  // anchovy
  { a: 'anchovy',  b: 'umami',    weight: 0.85 },
  { a: 'anchovy',  b: 'savory',   weight: 0.90 },
  { a: 'anchovy',  b: 'italian',  weight: 0.70 },

  // soy sauce
  { a: 'soy',      b: 'umami',    weight: 0.90 },
  { a: 'soy',      b: 'savory',   weight: 0.85 },
  { a: 'soy',      b: 'japanese', weight: 0.90 },

  // garlic
  { a: 'garlic',   b: 'savory',   weight: 0.80 },
  { a: 'garlic',   b: 'italian',  weight: 0.75 },
  { a: 'garlic',   b: 'indian',   weight: 0.70 },
];
